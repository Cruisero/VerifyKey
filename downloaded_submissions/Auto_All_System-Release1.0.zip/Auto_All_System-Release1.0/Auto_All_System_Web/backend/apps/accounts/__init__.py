# 用户账户模块
default_app_config = 'apps.accounts.apps.AccountsConfig'
