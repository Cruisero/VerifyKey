default_app_config = 'apps.cards.apps.CardsConfig'

