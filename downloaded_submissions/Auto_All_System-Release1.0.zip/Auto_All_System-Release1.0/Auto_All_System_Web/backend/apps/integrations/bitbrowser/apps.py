from django.apps import AppConfig


class BitbrowserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.integrations.bitbrowser'
    verbose_name = '比特浏览器集成'

