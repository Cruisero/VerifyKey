default_app_config = 'apps.integrations.proxies.apps.ProxiesConfig'

