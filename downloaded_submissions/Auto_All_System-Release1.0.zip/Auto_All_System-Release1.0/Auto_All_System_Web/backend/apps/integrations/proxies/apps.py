from django.apps import AppConfig


class ProxiesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.integrations.proxies'
    verbose_name = '代理管理'

