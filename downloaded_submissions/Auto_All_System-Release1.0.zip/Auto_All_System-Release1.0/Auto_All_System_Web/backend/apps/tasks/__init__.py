# 任务管理模块
default_app_config = 'apps.tasks.apps.TasksConfig'
