# 专区管理模块
default_app_config = 'apps.zones.apps.ZonesConfig'
