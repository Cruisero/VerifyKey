"""
Google Business插件
提供Google相关业务功能：SheerID验证、Gemini订阅
"""
from .plugin import Plugin

__version__ = '1.0.0'

# 导出插件实例
plugin = Plugin()

